
<?php 
$servername = "localhost";
$username = "root";
$password = "";
$db="crud2";

// Create connection
$conn = mysqli_connect($servername, $username, $password,$db);

// Check connection
if ($conn->connect_error){
  
  die("Connection failed: " . $connect->connect_error());
  
}
  if (isset($_POST["button"])) {
    $name=$_POST["Name"];
    $email =$_POST["email"];
    $password=$_POST["password"];
    $flexRadioDefault=$_POST["flexRadioDefault"];
    $select_box=$_POST["select_box"];

    if(isset($_FILES['image'])){
   $file_name=$_FILES['image']['name'];
   $file_size=$_FILES['image']['size'];
   $file_tmp=$_FILES['image']['tmp_name'];
   $file_type=$_FILES['image']['type'];

  move_uploaded_file($file_tmp,"upload-images/".$file_name);
    }

    $sql="INSERT INTO crdu_table(fname, email, password, flexRadioDefault, select_box,image) VALUES ('$name','$email','$password','$flexRadioDefault','$select_box','$file_name')";

$query=mysqli_query($conn,$sql);
    
    echo "Data Saved";    
} 
  


?> 

